package Book_Exchange_Platform.book.exchange.Controller;

import Book_Exchange_Platform.book.exchange.Exception.ResourceNotFoundException;
import Book_Exchange_Platform.book.exchange.Resources.Book;
import Book_Exchange_Platform.book.exchange.Resources.BookDTO;
import Book_Exchange_Platform.book.exchange.Service.BookService;
import Book_Exchange_Platform.book.exchange.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/auth")
public class BookController {

    @Autowired
    private BookService bookService;

    private final UserService userService;

    public BookController(UserService userService) {
        this.userService = userService;
    }


    @PostMapping("/add")
    public ResponseEntity<Book> addBook(@RequestParam("user_id") Long id, @RequestBody Book book) {
        Book savedBook = bookService.addBookToUser(id, book);
        return ResponseEntity.ok(savedBook);
    }

    @GetMapping("/books")
    public ResponseEntity<List<BookDTO>> getUserBooks(@RequestParam("user_id") Long userId) {
        List<BookDTO> books = bookService.getUserBooks(userId);
        return ResponseEntity.ok(books);
    }

    @DeleteMapping("/books/delete/{id}")
    public ResponseEntity<String> deleteBook(@PathVariable Long id) {
        try {
            bookService.deleteBook(id);
            return ResponseEntity.status(HttpStatus.OK).body("Book deleted successfully."); // Change from 204 to 200
        } catch (ResourceNotFoundException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Book not found.");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error occurred while deleting the book.");
        }
    }

    @PutMapping("/books/update/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable Long id, @RequestBody Book updatedBook) {
        Book book = bookService.updateBook(id, updatedBook);
        return ResponseEntity.ok(book);
    }

    @GetMapping("/available")
    public List<BookDTO> getAvailableBooks() {
        return bookService.getAllAvailableBooks();
    }
}

