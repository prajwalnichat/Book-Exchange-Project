package Book_Exchange_Platform.book.exchange.Resources;

import jakarta.persistence.*;

@Entity
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    public Book() {
    }

    private String title;
    private String author;
    private String genre;
    @Column(name = "book_condition")
    private String bookCondition;
    private boolean available;

    public Book( String title, String author, String genre, String bookCondition, boolean available) {
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.bookCondition = bookCondition;
        this.available = available;
    }
    public Book(Long id, String title, String author, String genre, String bookCondition, boolean available) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.bookCondition = bookCondition;
        this.available = available;
    }


    public String getBookCondition() {
        return bookCondition;
    }

    public void setBookCondition(String bookcondition) {
        this.bookCondition = bookcondition;
    }

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}

