package Book_Exchange_Platform.book.exchange.Repository;

import Book_Exchange_Platform.book.exchange.Resources.Book;
import Book_Exchange_Platform.book.exchange.Resources.BookDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface BookRepository extends JpaRepository<Book, Long> {
    List<Book> findByUserId(Long userId);

    // Query to fetch books with available = true
    @Query("SELECT new Book(b.id, b.title, b.author, b.genre, b.bookCondition, b.available) " +
            "FROM Book b WHERE b.available = true")
    List<BookDTO> findAllAvailableBooks();
}

